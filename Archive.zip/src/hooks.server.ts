import { redirect } from "@sveltejs/kit";

export async function handle({event, resolve}) {

    const response  = await resolve(event);

    if(event.url.pathname === '/') {
        throw redirect(302, '/login');
    }

    return response;
}