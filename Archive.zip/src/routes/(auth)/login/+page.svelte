<script lang="ts">
    import type { PageData } from './$types';
    
    export let data: PageData;
</script>

<form action="" method="post">
    <div>
        <label for="email">Email</label>
        <input type="email" name="email" id="email">
    </div>


    <div>
        <label for="password">Password</label>
        <input type="text" name="password" id="password">
    </div>

    <!-- <div class="error">Email is already</div> -->

    <button>Login</button>
</form>